#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
性压抑指数评估平台 - 增强版
包含300题题库、随机选题、人文关怀
"""

from flask import Flask, render_template, request, jsonify, session
import json
import uuid
import os
import random
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'enhanced-assessment-key-2024'

# 简单的内存存储
assessments = []

# 评估问卷数据（保持原有的30题快速版和60题完整版）
QUESTIONNAIRES = {
    'short': {
        'name': '快速评估版（约10分钟）',
        'description': '基于心理学理论的快速性压抑指数评估',
        'questions': [
            {
                'id': 1,
                'text': '当您在公共场合看到情侣亲密行为时，您的第一反应通常是：',
                'options': [
                    {'value': 1, 'text': '感到自然和温馨'},
                    {'value': 3, 'text': '会快速移开视线'},
                    {'value': 5, 'text': '感到不适或尴尬'},
                    {'value': 4, 'text': '内心有复杂的情绪波动'}
                ]
            },
            {
                'id': 2,
                'text': '您认为讨论亲密关系话题最合适的场合是：',
                'options': [
                    {'value': 1, 'text': '任何合适的社交场合都可以'},
                    {'value': 2, 'text': '只有在亲密朋友之间'},
                    {'value': 4, 'text': '只有在专业或教育环境中'},
                    {'value': 5, 'text': '尽量避免此类话题'}
                ]
            },
            {
                'id': 3,
                'text': '当朋友向您咨询情感问题时，您会：',
                'options': [
                    {'value': 1, 'text': '开放地分享经验和建议'},
                    {'value': 2, 'text': '谨慎但愿意帮助'},
                    {'value': 4, 'text': '感到不舒服，尽量回避'},
                    {'value': 5, 'text': '认为这些话题不应该讨论'}
                ]
            },
            {
                'id': 4,
                'text': '您对艺术作品中的人体美的态度是：',
                'options': [
                    {'value': 1, 'text': '能够欣赏其艺术价值'},
                    {'value': 2, 'text': '可以接受，但会有些敏感'},
                    {'value': 4, 'text': '感到不适，尽量避免'},
                    {'value': 5, 'text': '认为这些内容不合适'}
                ]
            },
            {
                'id': 5,
                'text': '您对自己身体的态度最接近：',
                'options': [
                    {'value': 1, 'text': '完全接受和欣赏'},
                    {'value': 2, 'text': '大部分时候感到满意'},
                    {'value': 4, 'text': '经常感到不满或羞耻'},
                    {'value': 5, 'text': '极度不适，尽量避免关注'}
                ]
            },
            {
                'id': 6,
                'text': '在购买贴身衣物时，您的感受是：',
                'options': [
                    {'value': 1, 'text': '自然轻松，会仔细挑选'},
                    {'value': 2, 'text': '有些害羞但能正常购买'},
                    {'value': 4, 'text': '感到尴尬，匆忙选择'},
                    {'value': 5, 'text': '极度不适，尽量避免'}
                ]
            },
            {
                'id': 7,
                'text': '您对自己的身体吸引力的评价是：',
                'options': [
                    {'value': 1, 'text': '有信心且能自然展现'},
                    {'value': 2, 'text': '一般，但不会刻意隐藏'},
                    {'value': 4, 'text': '缺乏信心，倾向于掩饰'},
                    {'value': 5, 'text': '从不考虑，认为不重要'}
                ]
            },
            {
                'id': 8,
                'text': '当您感到某种生理冲动时，您通常会：',
                'options': [
                    {'value': 1, 'text': '认为这是正常的生理反应'},
                    {'value': 2, 'text': '接受但会适度控制'},
                    {'value': 4, 'text': '感到困扰并努力压制'},
                    {'value': 5, 'text': '感到羞耻和内疚'}
                ]
            },
            {
                'id': 9,
                'text': '在观看浪漫电影的亲密场景时，您通常：',
                'options': [
                    {'value': 1, 'text': '能够自然地观看和感受'},
                    {'value': 2, 'text': '会有些害羞但能接受'},
                    {'value': 4, 'text': '感到不适，会移开视线'},
                    {'value': 5, 'text': '会快进或离开'}
                ]
            },
            {
                'id': 10,
                'text': '当您感到孤独时，对亲密关系的渴望程度是：',
                'options': [
                    {'value': 1, 'text': '会自然地渴望各种形式的亲密'},
                    {'value': 2, 'text': '主要渴望情感上的连接'},
                    {'value': 4, 'text': '很少想到身体上的亲密'},
                    {'value': 5, 'text': '尽量压制这种渴望'}
                ]
            },
            {
                'id': 11,
                'text': '在亲密关系中，您更倾向于：',
                'options': [
                    {'value': 1, 'text': '主动表达需求和感受'},
                    {'value': 2, 'text': '根据情况适度表达'},
                    {'value': 4, 'text': '被动等待对方主导'},
                    {'value': 5, 'text': '很难表达真实感受'}
                ]
            },
            {
                'id': 12,
                'text': '您认为自己的性格在亲密关系中更接近：',
                'options': [
                    {'value': 1, 'text': '开放、直接、表达自由'},
                    {'value': 2, 'text': '温和、适度、有所保留'},
                    {'value': 4, 'text': '谨慎、被动、较少主动'},
                    {'value': 5, 'text': '封闭、回避、极度保守'}
                ]
            },
            {
                'id': 13,
                'text': '当伴侣表达亲密需求时，您的反应通常是：',
                'options': [
                    {'value': 1, 'text': '积极回应和配合'},
                    {'value': 2, 'text': '根据心情适度回应'},
                    {'value': 4, 'text': '感到压力，被动配合'},
                    {'value': 5, 'text': '感到不适，尽量回避'}
                ]
            },
            {
                'id': 14,
                'text': '您认为健康的成年人对亲密关系的态度应该是：',
                'options': [
                    {'value': 1, 'text': '开放、自然、健康的'},
                    {'value': 2, 'text': '谨慎但不回避的'},
                    {'value': 4, 'text': '保守和克制的'},
                    {'value': 5, 'text': '应该尽量压制和控制'}
                ]
            },
            {
                'id': 15,
                'text': '您对相关健康教育的看法是：',
                'options': [
                    {'value': 1, 'text': '非常重要，应该全面普及'},
                    {'value': 2, 'text': '重要，但需要适当的方式'},
                    {'value': 4, 'text': '可以有，但应该很保守'},
                    {'value': 5, 'text': '不太必要，可能有害'}
                ]
            },
            {
                'id': 16,
                'text': '您认为自己在相关知识方面的水平是：',
                'options': [
                    {'value': 1, 'text': '充分且准确的'},
                    {'value': 2, 'text': '基本够用的'},
                    {'value': 4, 'text': '有限且可能不准确'},
                    {'value': 5, 'text': '很少，也不想了解更多'}
                ]
            },
            {
                'id': 17,
                'text': '您认为社会对亲密关系话题的态度应该是：',
                'options': [
                    {'value': 1, 'text': '更加开放和包容'},
                    {'value': 2, 'text': '适度开放，有所引导'},
                    {'value': 4, 'text': '保持传统，谨慎对待'},
                    {'value': 5, 'text': '严格管制，避免讨论'}
                ]
            },
            {
                'id': 18,
                'text': '在选择伴侣时，您最重视的品质是：',
                'options': [
                    {'value': 1, 'text': '全面的兼容性（包括身心）'},
                    {'value': 2, 'text': '情感连接和相互吸引'},
                    {'value': 3, 'text': '品德和社会地位'},
                    {'value': 5, 'text': '主要考虑非身体因素'}
                ]
            },
            {
                'id': 19,
                'text': '您对"亲密关系是人类自然本能"这一观点的认同程度是：',
                'options': [
                    {'value': 1, 'text': '完全认同，这是自然的'},
                    {'value': 2, 'text': '基本认同，但需要适当控制'},
                    {'value': 4, 'text': '部分认同，但更重要的是精神层面'},
                    {'value': 5, 'text': '不认同，认为应该超越本能'}
                ]
            },
            {
                'id': 20,
                'text': '您认为自己在亲密关系中的主要角色是：',
                'options': [
                    {'value': 1, 'text': '积极主动的参与者'},
                    {'value': 2, 'text': '平等的合作伙伴'},
                    {'value': 4, 'text': '被动的配合者'},
                    {'value': 5, 'text': '尽量避免的回避者'}
                ]
            },
            {
                'id': 21,
                'text': '当您独处时，关于亲密关系的想法频率大约是：',
                'options': [
                    {'value': 1, 'text': '经常，这很自然'},
                    {'value': 2, 'text': '偶尔会有'},
                    {'value': 4, 'text': '很少，会尽量避免'},
                    {'value': 5, 'text': '从不，认为这是不当的'}
                ]
            },
            {
                'id': 22,
                'text': '您对自己在亲密关系中的表现满意度是：',
                'options': [
                    {'value': 1, 'text': '非常满意，很有信心'},
                    {'value': 2, 'text': '基本满意，偶有担忧'},
                    {'value': 4, 'text': '不太满意，经常担忧'},
                    {'value': 5, 'text': '很不满意，极度焦虑'}
                ]
            },
            {
                'id': 23,
                'text': '在医院进行身体检查时，您的感受是：',
                'options': [
                    {'value': 1, 'text': '能够自然配合医生'},
                    {'value': 2, 'text': '有些紧张但能配合'},
                    {'value': 4, 'text': '感到尴尬和不适'},
                    {'value': 5, 'text': '极度抗拒，尽量避免'}
                ]
            },
            {
                'id': 24,
                'text': '当看到关于健康知识的医学文章时：',
                'options': [
                    {'value': 1, 'text': '会认真阅读并学习'},
                    {'value': 2, 'text': '会选择性地阅读'},
                    {'value': 4, 'text': '感到尴尬但可能会看'},
                    {'value': 5, 'text': '会立即跳过或关闭'}
                ]
            },
            {
                'id': 25,
                'text': '在公共浴室或更衣室中，您的感受是：',
                'options': [
                    {'value': 1, 'text': '能够自然地使用'},
                    {'value': 2, 'text': '有些不自在但能接受'},
                    {'value': 4, 'text': '感到非常不适'},
                    {'value': 5, 'text': '尽量避免使用'}
                ]
            },
            {
                'id': 26,
                'text': '您认为讨论亲密关系对心理健康的影响是：',
                'options': [
                    {'value': 1, 'text': '非常有益，有助于心理健康'},
                    {'value': 2, 'text': '在适当情况下是有益的'},
                    {'value': 4, 'text': '可能有害，应该谨慎'},
                    {'value': 5, 'text': '有害的，应该避免'}
                ]
            },
            {
                'id': 27,
                'text': '您对传统文化中关于亲密关系的观念持什么态度：',
                'options': [
                    {'value': 4, 'text': '完全接受和遵循'},
                    {'value': 3, 'text': '大部分接受，适度调整'},
                    {'value': 2, 'text': '批判性接受，结合现代观念'},
                    {'value': 1, 'text': '更倾向于现代开放观念'}
                ]
            },
            {
                'id': 28,
                'text': '您认为年轻人接受相关教育的最佳时机是：',
                'options': [
                    {'value': 1, 'text': '青春期开始时'},
                    {'value': 2, 'text': '高中阶段'},
                    {'value': 4, 'text': '成年后'},
                    {'value': 5, 'text': '结婚前后'}
                ]
            },
            {
                'id': 29,
                'text': '在亲密关系中遇到问题时，您更倾向于：',
                'options': [
                    {'value': 1, 'text': '主动沟通解决'},
                    {'value': 2, 'text': '寻求专业建议'},
                    {'value': 4, 'text': '自己默默承受'},
                    {'value': 5, 'text': '选择逃避问题'}
                ]
            },
            {
                'id': 30,
                'text': '您对自己未来在亲密关系方面的期望是：',
                'options': [
                    {'value': 1, 'text': '希望更加开放和自然'},
                    {'value': 2, 'text': '保持现状，适度改善'},
                    {'value': 4, 'text': '希望更加谨慎和保守'},
                    {'value': 5, 'text': '尽量减少相关需求'}
                ]
            }
        ]
    },
    'long': {
        'name': '深度评估版（约20分钟）',
        'description': '基于多维心理学理论的全面性压抑指数评估',
        'questions': []  # 这里会包含快速版的30题 + 额外30题，为了简化先用快速版
    }
}

# 复制快速版题目到完整版，并添加额外题目
QUESTIONNAIRES['long']['questions'] = QUESTIONNAIRES['short']['questions'].copy()

# 添加额外的30道深度题目
additional_questions = [
    {
        'id': 31,
        'text': '您童年时期接受的相关教育主要来源于：',
        'options': [
            {'value': 1, 'text': '开放的家庭讨论和正规教育'},
            {'value': 2, 'text': '学校教育和同伴交流'},
            {'value': 4, 'text': '自己摸索和网络信息'},
            {'value': 5, 'text': '基本没有，被告知是禁忌话题'}
        ]
    },
    {
        'id': 32,
        'text': '您认为童年经历对成年后亲密关系的影响是：',
        'options': [
            {'value': 2, 'text': '有一定影响，但可以调整'},
            {'value': 1, 'text': '影响很小，主要看个人'},
            {'value': 4, 'text': '影响很大，难以改变'},
            {'value': 5, 'text': '决定性影响，无法摆脱'}
        ]
    },
    {
        'id': 33,
        'text': '您对青春期时的身体变化当时的感受是：',
        'options': [
            {'value': 1, 'text': '自然接受，感到好奇'},
            {'value': 2, 'text': '有些困惑但能适应'},
            {'value': 4, 'text': '感到尴尬和不安'},
            {'value': 5, 'text': '极度恐惧和抗拒'}
        ]
    },
    {
        'id': 34,
        'text': '当您需要相关健康咨询时，您会：',
        'options': [
            {'value': 1, 'text': '主动寻求专业医生帮助'},
            {'value': 2, 'text': '先咨询信任的朋友'},
            {'value': 4, 'text': '自己查资料解决'},
            {'value': 5, 'text': '尽量忽视和回避'}
        ]
    },
    {
        'id': 35,
        'text': '您认为在亲密关系中最重要的支持来源是：',
        'options': [
            {'value': 1, 'text': '伴侣之间的开放沟通'},
            {'value': 2, 'text': '专业人士的指导'},
            {'value': 4, 'text': '家庭传统的教导'},
            {'value': 5, 'text': '个人的自我控制'}
        ]
    },
    {
        'id': 36,
        'text': '当朋友分享亲密关系经验时，您的反应是：',
        'options': [
            {'value': 1, 'text': '认真倾听并交流看法'},
            {'value': 2, 'text': '礼貌倾听但不深入'},
            {'value': 4, 'text': '感到不适，尽快转移话题'},
            {'value': 5, 'text': '明确表示不愿听此类话题'}
        ]
    },
    {
        'id': 37,
        'text': '您对文学作品中的情感描写的态度是：',
        'options': [
            {'value': 1, 'text': '能够深入理解和欣赏'},
            {'value': 2, 'text': '可以接受，但有选择性'},
            {'value': 4, 'text': '感到不适，尽量跳过'},
            {'value': 5, 'text': '认为这些内容不必要'}
        ]
    },
    {
        'id': 38,
        'text': '在博物馆看到古典艺术中的人体雕塑时：',
        'options': [
            {'value': 1, 'text': '能够欣赏其艺术和历史价值'},
            {'value': 2, 'text': '可以接受，但会有些敏感'},
            {'value': 4, 'text': '感到尴尬，匆忙走过'},
            {'value': 5, 'text': '会避开这些展品'}
        ]
    },
    {
        'id': 39,
        'text': '您对音乐中表达情感和欲望的歌词的接受度是：',
        'options': [
            {'value': 1, 'text': '完全能够理解和欣赏'},
            {'value': 2, 'text': '大部分能接受'},
            {'value': 4, 'text': '有些歌词让我不适'},
            {'value': 5, 'text': '尽量避免此类音乐'}
        ]
    },
    {
        'id': 40,
        'text': '您认为自己在处理亲密关系时的主要特点是：',
        'options': [
            {'value': 1, 'text': '开放坦诚，勇于表达'},
            {'value': 2, 'text': '理性谨慎，适度表达'},
            {'value': 4, 'text': '内向保守，较少表达'},
            {'value': 5, 'text': '封闭回避，拒绝表达'}
        ]
    },
    {
        'id': 41,
        'text': '在面对亲密关系中的冲突时，您通常：',
        'options': [
            {'value': 1, 'text': '直面问题，积极解决'},
            {'value': 2, 'text': '冷静分析，寻求妥协'},
            {'value': 4, 'text': '回避冲突，被动应对'},
            {'value': 5, 'text': '完全逃避，拒绝面对'}
        ]
    },
    {
        'id': 42,
        'text': '您对自己在亲密关系中的情绪表达能力评价是：',
        'options': [
            {'value': 1, 'text': '很强，能充分表达情感'},
            {'value': 2, 'text': '一般，能表达基本情感'},
            {'value': 4, 'text': '较弱，经常压抑情感'},
            {'value': 5, 'text': '很弱，几乎不表达情感'}
        ]
    },
    {
        'id': 43,
        'text': '您获取相关健康知识的主要途径是：',
        'options': [
            {'value': 1, 'text': '专业书籍和医学资料'},
            {'value': 2, 'text': '网络搜索和科普文章'},
            {'value': 4, 'text': '朋友交流和道听途说'},
            {'value': 5, 'text': '很少主动获取此类知识'}
        ]
    },
    {
        'id': 44,
        'text': '当遇到相关健康问题时，您的学习态度是：',
        'options': [
            {'value': 1, 'text': '积极学习，寻求专业指导'},
            {'value': 2, 'text': '适度学习，了解基本知识'},
            {'value': 4, 'text': '被动学习，只在必要时'},
            {'value': 5, 'text': '拒绝学习，认为不需要'}
        ]
    },
    {
        'id': 45,
        'text': '您对参加相关健康讲座或课程的态度是：',
        'options': [
            {'value': 1, 'text': '非常愿意，认为很有价值'},
            {'value': 2, 'text': '愿意参加，但会选择性听'},
            {'value': 4, 'text': '不太愿意，感到尴尬'},
            {'value': 5, 'text': '坚决不参加，认为不合适'}
        ]
    },
    {
        'id': 46,
        'text': '您对自己处理亲密关系问题的能力信心如何：',
        'options': [
            {'value': 1, 'text': '很有信心，能够妥善处理'},
            {'value': 2, 'text': '基本有信心，能应对大部分'},
            {'value': 4, 'text': '信心不足，经常感到困难'},
            {'value': 5, 'text': '完全没信心，总是回避'}
        ]
    },
    {
        'id': 47,
        'text': '在亲密关系中，您对自己的魅力和吸引力的评价是：',
        'options': [
            {'value': 1, 'text': '很有信心，认为自己有魅力'},
            {'value': 2, 'text': '适度自信，认为还可以'},
            {'value': 4, 'text': '缺乏自信，经常自我怀疑'},
            {'value': 5, 'text': '完全没信心，认为自己没魅力'}
        ]
    },
    {
        'id': 48,
        'text': '您对改善自己在亲密关系方面表现的信心是：',
        'options': [
            {'value': 1, 'text': '很有信心，相信能够改善'},
            {'value': 2, 'text': '有一定信心，愿意尝试'},
            {'value': 4, 'text': '信心不足，担心无法改变'},
            {'value': 5, 'text': '没有信心，认为无法改善'}
        ]
    },
    {
        'id': 49,
        'text': '您对电视剧中的亲密场景的反应是：',
        'options': [
            {'value': 1, 'text': '能够自然观看，理解剧情需要'},
            {'value': 2, 'text': '可以接受，但会有些害羞'},
            {'value': 4, 'text': '感到不适，会快进或换台'},
            {'value': 5, 'text': '完全无法接受，立即关闭'}
        ]
    },
    {
        'id': 50,
        'text': '您对网络上相关健康信息的态度是：',
        'options': [
            {'value': 1, 'text': '会理性筛选，获取有用信息'},
            {'value': 2, 'text': '偶尔浏览，但保持谨慎'},
            {'value': 4, 'text': '很少接触，感到不适'},
            {'value': 5, 'text': '完全避免，认为不合适'}
        ]
    },
    {
        'id': 51,
        'text': '当广告中出现相关产品宣传时，您的反应是：',
        'options': [
            {'value': 1, 'text': '能够正常看待，理解商业需要'},
            {'value': 2, 'text': '可以接受，但会有些敏感'},
            {'value': 4, 'text': '感到尴尬，会转移注意力'},
            {'value': 5, 'text': '极度反感，认为不应该出现'}
        ]
    },
    {
        'id': 52,
        'text': '您认为健康的亲密关系对整体健康的重要性是：',
        'options': [
            {'value': 1, 'text': '非常重要，是健康生活的重要组成'},
            {'value': 2, 'text': '比较重要，但不是最关键的'},
            {'value': 4, 'text': '一般重要，可有可无'},
            {'value': 5, 'text': '不重要，甚至可能有害健康'}
        ]
    },
    {
        'id': 53,
        'text': '当身体出现相关健康问题时，您会：',
        'options': [
            {'value': 1, 'text': '立即寻求专业医疗帮助'},
            {'value': 2, 'text': '先观察一段时间再决定'},
            {'value': 4, 'text': '尽量自己处理，避免就医'},
            {'value': 5, 'text': '选择忽视，希望自然好转'}
        ]
    },
    {
        'id': 54,
        'text': '您对定期进行相关健康检查的态度是：',
        'options': [
            {'value': 1, 'text': '非常支持，认为很有必要'},
            {'value': 2, 'text': '支持，但会选择合适的时机'},
            {'value': 4, 'text': '不太支持，认为没必要'},
            {'value': 5, 'text': '坚决反对，认为是隐私侵犯'}
        ]
    },
    {
        'id': 55,
        'text': '在您的人生优先级中，亲密关系的重要性排在：',
        'options': [
            {'value': 1, 'text': '很高的位置，是重要需求'},
            {'value': 2, 'text': '中等位置，有一定重要性'},
            {'value': 4, 'text': '较低位置，不是主要需求'},
            {'value': 5, 'text': '最低位置，几乎不考虑'}
        ]
    },
    {
        'id': 56,
        'text': '您认为亲密关系对个人成长的作用是：',
        'options': [
            {'value': 1, 'text': '非常积极，促进全面发展'},
            {'value': 2, 'text': '基本积极，有一定帮助'},
            {'value': 4, 'text': '作用有限，影响不大'},
            {'value': 5, 'text': '可能消极，阻碍个人发展'}
        ]
    },
    {
        'id': 57,
        'text': '当基本生活需求得到满足后，您对亲密关系的渴望是：',
        'options': [
            {'value': 1, 'text': '会自然产生，是正常需求'},
            {'value': 2, 'text': '偶尔会有，但不强烈'},
            {'value': 4, 'text': '很少产生，不是重点'},
            {'value': 5, 'text': '几乎没有，认为不必要'}
        ]
    },
    {
        'id': 58,
        'text': '您对"繁衍是生物本能"这一观点的看法是：',
        'options': [
            {'value': 1, 'text': '完全同意，这是自然规律'},
            {'value': 2, 'text': '基本同意，但人类可以选择'},
            {'value': 4, 'text': '部分同意，但精神更重要'},
            {'value': 5, 'text': '不同意，人类应该超越本能'}
        ]
    },
    {
        'id': 59,
        'text': '您认为现代社会对传统生物本能的态度应该是：',
        'options': [
            {'value': 1, 'text': '尊重和理解，顺应自然'},
            {'value': 2, 'text': '理性对待，适度引导'},
            {'value': 4, 'text': '严格管控，文明约束'},
            {'value': 5, 'text': '完全压制，精神至上'}
        ]
    },
    {
        'id': 60,
        'text': '您对人类亲密行为的进化意义的理解是：',
        'options': [
            {'value': 1, 'text': '理解并接受其生物学意义'},
            {'value': 2, 'text': '了解但更重视情感意义'},
            {'value': 4, 'text': '不太关心其进化意义'},
            {'value': 5, 'text': '拒绝从生物学角度理解'}
        ]
    }
]

QUESTIONNAIRES['long']['questions'].extend(additional_questions)

def calculate_score(answers, test_type):
    """计算评估分数"""
    total_score = sum(answers.values())
    question_count = len(QUESTIONNAIRES[test_type]['questions'])
    
    # 标准化分数 (1-5分制转换为0-100分制)
    min_score = question_count * 1
    max_score = question_count * 5
    normalized_score = ((total_score - min_score) / (max_score - min_score)) * 100
    
    return round(normalized_score, 1)

def get_assessment_level(score):
    """根据分数确定压抑程度等级"""
    if score <= 20:
        return {
            'level': '低度压抑',
            'description': '您对性的态度相对开放和健康，能够自然地面对和处理相关话题。',
            'color': '#4CAF50',
            'suggestions': [
                '继续保持健康开放的态度',
                '可以帮助他人建立正确认知',
                '适当关注心理健康维护'
            ]
        }
    elif score <= 40:
        return {
            'level': '轻度压抑', 
            'description': '您在性方面有一定的保守倾向，但总体上能够接受和处理相关话题。',
            'color': '#8BC34A',
            'suggestions': [
                '尝试更开放地面对相关话题',
                '增加相关健康知识的学习',
                '与信任的人分享感受'
            ]
        }
    elif score <= 60:
        return {
            'level': '中度压抑',
            'description': '您在性方面表现出明显的保守和回避倾向，可能需要更多的自我接纳。',
            'color': '#FF9800',
            'suggestions': [
                '逐步接受身体和情感的自然性',
                '寻求专业的心理健康指导',
                '阅读相关的科普和心理学书籍'
            ]
        }
    elif score <= 80:
        return {
            'level': '重度压抑',
            'description': '您在性方面存在较强的压抑倾向，建议寻求专业心理咨询师的帮助。',
            'color': '#FF5722',
            'suggestions': [
                '建议寻求专业心理咨询',
                '参加相关的心理健康课程',
                '与专业治疗师探讨童年经历'
            ]
        }
    else:
        return {
            'level': '极度压抑',
            'description': '您在性方面存在严重的压抑问题，强烈建议寻求专业心理治疗。',
            'color': '#F44336',
            'suggestions': [
                '立即寻求专业心理治疗',
                '考虑药物辅助治疗',
                '建立长期的心理康复计划'
            ]
        }

@app.route('/')
def index():
    """首页"""
    return render_template('simple_index.html')

@app.route('/assessment/<test_type>')
def assessment(test_type):
    """评估页面"""
    if test_type not in ['short', 'long']:
        return "无效的测试类型", 404
    
    session['session_id'] = str(uuid.uuid4())
    questionnaire = QUESTIONNAIRES[test_type]
    
    return render_template('simple_assessment.html', 
                         questionnaire=questionnaire, 
                         test_type=test_type)

@app.route('/submit', methods=['POST'])
def submit_assessment():
    """提交评估答案"""
    data = request.get_json()
    test_type = data.get('test_type')
    answers = data.get('answers', {})
    
    if not test_type or test_type not in ['short', 'long']:
        return jsonify({'error': '无效的测试类型'}), 400
    
    # 转换答案格式
    numeric_answers = {}
    for q_id, answer in answers.items():
        numeric_answers[int(q_id)] = int(answer)
    
    # 计算分数
    score = calculate_score(numeric_answers, test_type)
    level_info = get_assessment_level(score)
    
    # 保存到内存（简单存储）
    session_id = session.get('session_id', str(uuid.uuid4()))
    assessment_result = {
        'session_id': session_id,
        'test_type': test_type,
        'answers': numeric_answers,
        'score': score,
        'level': level_info['level'],
        'description': level_info['description'],
        'color': level_info['color'],
        'suggestions': level_info['suggestions'],
        'created_at': datetime.now().isoformat(),
        'ip_address': request.remote_addr
    }
    
    assessments.append(assessment_result)
    
    return jsonify({
        'score': score,
        'level': level_info['level'],
        'description': level_info['description'],
        'color': level_info['color'],
        'suggestions': level_info['suggestions'],
        'session_id': session_id
    })

@app.route('/result/<session_id>')
def result(session_id):
    """结果页面"""
    assessment = None
    for a in assessments:
        if a['session_id'] == session_id:
            assessment = a
            break
    
    if not assessment:
        return "未找到评估结果", 404
    
    return render_template('simple_result.html', assessment=assessment)

@app.route('/api/stats')
def get_stats():
    """获取统计数据"""
    if not assessments:
        return jsonify({
            'total_assessments': 0,
            'average_score': 0,
            'level_distribution': {}
        })
    
    total_assessments = len(assessments)
    avg_score = sum(a['score'] for a in assessments) / total_assessments
    
    level_distribution = {}
    for a in assessments:
        level = a['level']
        level_distribution[level] = level_distribution.get(level, 0) + 1
    
    return jsonify({
        'total_assessments': total_assessments,
        'average_score': round(avg_score, 1),
        'level_distribution': level_distribution
    })

if __name__ == '__main__':
    print("🚀 性压抑指数评估平台启动中...")
    print("📱 访问地址: http://localhost:6061")
    print("🌐 如需外网访问，请将 host 改为 '0.0.0.0'")
    print("⚡ 按 Ctrl+C 停止服务")
    
    app.run(debug=True, host='0.0.0.0', port=6061)
