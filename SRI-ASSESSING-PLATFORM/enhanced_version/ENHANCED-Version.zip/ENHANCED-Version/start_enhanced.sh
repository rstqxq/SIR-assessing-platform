#!/bin/bash

# 性压抑指数评估平台 - 增强版启动脚本
# 包含300题题库、随机选题、人文关怀

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# 显示欢迎信息
echo -e "${PURPLE}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                    性压抑指数评估平台                          ║"
echo "║                     增强版 v2.0                             ║"
echo "║                                                              ║"
echo "║  🎲 600题题库 | 💝 人文关怀 | 🎯 5种版本 | ⚡ 智能选题      ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo

# 检查Python
echo -e "${BLUE}[1/4]${NC} 检查Python环境..."
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ 未找到Python3，请先安装Python3${NC}"
    exit 1
fi

PYTHON_VERSION=$(python3 --version 2>&1 | cut -d' ' -f2)
echo -e "${GREEN}✅ Python ${PYTHON_VERSION} 已安装${NC}"

# 检查并安装依赖
echo -e "${BLUE}[2/4]${NC} 检查依赖包..."
if ! python3 -c "import flask" 2>/dev/null; then
    echo -e "${YELLOW}⚠️  Flask未安装，正在安装...${NC}"
    pip3 install flask --user -q
    echo -e "${GREEN}✅ Flask安装完成${NC}"
else
    echo -e "${GREEN}✅ Flask已安装${NC}"
fi

# 检查端口占用
echo -e "${BLUE}[3/4]${NC} 检查端口6061..."
if lsof -Pi :6061 -sTCP:LISTEN -t >/dev/null 2>&1; then
    echo -e "${YELLOW}⚠️  端口6061已被占用，尝试使用其他端口...${NC}"
    PORT=6062
    while lsof -Pi :$PORT -sTCP:LISTEN -t >/dev/null 2>&1; do
        PORT=$((PORT + 1))
        if [ $PORT -gt 6070 ]; then
            echo -e "${RED}❌ 无法找到可用端口${NC}"
            exit 1
        fi
    done
    echo -e "${GREEN}✅ 将使用端口 ${PORT}${NC}"
else
    PORT=6061
    echo -e "${GREEN}✅ 端口6061可用${NC}"
fi

# 启动应用
echo -e "${BLUE}[4/4]${NC} 启动增强版应用..."
echo

# 修改端口并启动
if [ $PORT -ne 6061 ]; then
    sed -i.bak "s/port=6061/port=$PORT/g" enhanced_app.py
fi

echo -e "${GREEN}🎉 增强版应用启动成功！${NC}"
echo
echo -e "${CYAN}✨ 新功能特性:${NC}"
echo -e "   🎲 ${YELLOW}智能随机选题${NC} - 从600题库中随机选择"
echo -e "   💝 ${YELLOW}人文关怀设计${NC} - 温暖的结果解读"
echo -e "   🎯 ${YELLOW}多版本评估${NC} - 20/40/60/100/120题"
echo -e "   📊 ${YELLOW}专业级分析${NC} - 6大心理学维度"
echo
echo -e "${PURPLE}📱 访问地址:${NC}"
echo -e "   本地访问: ${BLUE}http://localhost:$PORT${NC}"

# 获取本机IP
if command -v hostname &> /dev/null; then
    LOCAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "获取失败")
    if [ "$LOCAL_IP" != "获取失败" ] && [ -n "$LOCAL_IP" ]; then
        echo -e "   局域网访问: ${BLUE}http://$LOCAL_IP:$PORT${NC}"
    fi
fi

echo
echo -e "${CYAN}🎯 评估版本说明:${NC}"
echo "   ⚡ 快速版(20题) - 约8分钟，快速了解"
echo "   📊 标准版(40题) - 约15分钟，全面评估"
echo "   🔍 深度版(60题) - 约25分钟，详细分析"
echo "   🎯 全面版(100题) - 约35分钟，专业分析"
echo "   🏆 专业版(120题) - 约45分钟，咨询参考"
echo
echo -e "${YELLOW}💡 使用提示:${NC}"
echo "   • 每次评估都会随机选题，避免重复"
echo "   • 支持手机和电脑访问"
echo "   • 完全匿名，保护隐私"
echo "   • 结果包含人文关怀和专业建议"
echo "   • 按 Ctrl+C 停止服务"
echo
echo -e "${PURPLE}⚡ 正在启动服务器...${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 启动Flask应用
python3 enhanced_app.py

# 恢复原始文件（如果修改了端口）
if [ $PORT -ne 6061 ] && [ -f enhanced_app.py.bak ]; then
    mv enhanced_app.py.bak enhanced_app.py
fi
