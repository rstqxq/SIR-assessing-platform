#!/bin/bash

# 性压抑指数评估平台 - 极简版启动脚本
# 一键启动，无需复杂配置

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# 显示欢迎信息
echo -e "${PURPLE}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                    性压抑指数评估平台                          ║"
echo "║                      极简版 v1.0                            ║"
echo "║                                                              ║"
echo "║  🚀 一键启动 | 📱 响应式设计 | 🔒 完全匿名 | ⚡ 即时结果      ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo

# 检查Python
echo -e "${BLUE}[1/4]${NC} 检查Python环境..."
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ 未找到Python3，请先安装Python3${NC}"
    exit 1
fi

PYTHON_VERSION=$(python3 --version 2>&1 | cut -d' ' -f2)
echo -e "${GREEN}✅ Python ${PYTHON_VERSION} 已安装${NC}"

# 检查并安装依赖
echo -e "${BLUE}[2/4]${NC} 检查依赖包..."
if ! python3 -c "import flask" 2>/dev/null; then
    echo -e "${YELLOW}⚠️  Flask未安装，正在安装...${NC}"
    pip3 install flask --user -q
    echo -e "${GREEN}✅ Flask安装完成${NC}"
else
    echo -e "${GREEN}✅ Flask已安装${NC}"
fi

# 检查端口占用
echo -e "${BLUE}[3/4]${NC} 检查端口6061..."
if lsof -Pi :6061 -sTCP:LISTEN -t >/dev/null 2>&1; then
    echo -e "${YELLOW}⚠️  端口6061已被占用，尝试使用其他端口...${NC}"
    PORT=6062
    while lsof -Pi :$PORT -sTCP:LISTEN -t >/dev/null 2>&1; do
        PORT=$((PORT + 1))
        if [ $PORT -gt 6070 ]; then
            echo -e "${RED}❌ 无法找到可用端口${NC}"
            exit 1
        fi
    done
    echo -e "${GREEN}✅ 将使用端口 ${PORT}${NC}"
else
    PORT=6061
    echo -e "${GREEN}✅ 端口6061可用${NC}"
fi

# 启动应用
echo -e "${BLUE}[4/4]${NC} 启动应用..."
echo

# 修改端口并启动
if [ $PORT -ne 6061 ]; then
    sed -i.bak "s/port=6061/port=$PORT/g" simple_app.py
fi

echo -e "${GREEN}🎉 应用启动成功！${NC}"
echo
echo -e "${PURPLE}📱 访问地址:${NC}"
echo -e "   本地访问: ${BLUE}http://localhost:$PORT${NC}"

# 获取本机IP
if command -v hostname &> /dev/null; then
    LOCAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "获取失败")
    if [ "$LOCAL_IP" != "获取失败" ] && [ -n "$LOCAL_IP" ]; then
        echo -e "   局域网访问: ${BLUE}http://$LOCAL_IP:$PORT${NC}"
    fi
fi

echo
echo -e "${YELLOW}💡 使用提示:${NC}"
echo "   • 支持手机和电脑访问"
echo "   • 完全匿名，无需注册"
echo "   • 结果即时生成"
echo "   • 按 Ctrl+C 停止服务"
echo
echo -e "${PURPLE}⚡ 正在启动服务器...${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 启动Flask应用
python3 simple_app.py

# 恢复原始文件（如果修改了端口）
if [ $PORT -ne 6061 ] && [ -f simple_app.py.bak ]; then
    mv simple_app.py.bak simple_app.py
fi
